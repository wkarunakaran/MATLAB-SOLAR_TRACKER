# MATLAB_Simulink_Project--design-and-simulate-Solar-Tracking-System-
 This project depicts the simulation work of solar tracking system with motor, panel and PID controller subsystems. Here I also test my design by givign the model refrence data as input.
